globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/": [
      "static/chunks/node_modules_next_dist_compiled_next-devtools_index_5277ebc8.js",
      "static/chunks/node_modules_next_dist_compiled_aa9d047d._.js",
      "static/chunks/node_modules_next_dist_shared_lib_16fa510a._.js",
      "static/chunks/node_modules_next_dist_client_bdba867a._.js",
      "static/chunks/node_modules_next_dist_2e2215b7._.js",
      "static/chunks/node_modules_next_image_e7eb52cb.js",
      "static/chunks/node_modules_react-dom_4411d9bd._.js",
      "static/chunks/node_modules_db346ff0._.js",
      "static/chunks/[root-of-the-server]__65fbe05e._.js",
      "static/chunks/[next]_internal_font_google_d84389e8._.css",
      "static/chunks/pages_index_2da965e7._.js",
      "static/chunks/turbopack-pages_index_fcba632e._.js"
    ],
    "/_app": [
      "static/chunks/node_modules_next_dist_compiled_next-devtools_index_5277ebc8.js",
      "static/chunks/node_modules_next_dist_compiled_166120c5._.js",
      "static/chunks/node_modules_next_dist_shared_lib_2c2ec201._.js",
      "static/chunks/node_modules_next_dist_client_d0aa886c._.js",
      "static/chunks/node_modules_next_dist_2e2215b7._.js",
      "static/chunks/node_modules_react-dom_4411d9bd._.js",
      "static/chunks/node_modules_db346ff0._.js",
      "static/chunks/[root-of-the-server]__01feb856._.js",
      "static/chunks/styles_globals_dc36e6c9.css",
      "static/chunks/pages__app_2da965e7._.js",
      "static/chunks/turbopack-pages__app_2b3cf8e2._.js"
    ],
    "/form": [
      "static/chunks/[root-of-the-server]__da5af0fd._.js",
      "static/chunks/node_modules_next_dist_compiled_next-devtools_index_5277ebc8.js",
      "static/chunks/node_modules_next_dist_compiled_166120c5._.js",
      "static/chunks/node_modules_next_dist_shared_lib_2c2ec201._.js",
      "static/chunks/node_modules_next_dist_client_d0aa886c._.js",
      "static/chunks/node_modules_next_dist_2e2215b7._.js",
      "static/chunks/node_modules_react-dom_4411d9bd._.js",
      "static/chunks/node_modules_db346ff0._.js",
      "static/chunks/pages_form_2da965e7._.js",
      "static/chunks/turbopack-pages_form_fd3029c2._.js"
    ]
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [],
  "lowPriorityFiles": [],
  "rootMainFiles": [],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];