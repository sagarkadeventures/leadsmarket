var R=require("../chunks/ssr/[turbopack]_runtime.js")("server/pages/index.js")
R.c("server/chunks/ssr/node_modules_0b53a5be._.js")
R.c("server/chunks/ssr/[root-of-the-server]__3c8416e4._.js")
R.c("server/chunks/ssr/pages__app_43455d5d.js")
R.c("server/chunks/ssr/node_modules_36b963e9._.js")
R.c("server/chunks/ssr/[root-of-the-server]__95b76db2._.js")
R.m("[project]/node_modules/next/dist/esm/build/templates/pages.js { INNER_PAGE => \"[project]/pages/index.js [ssr] (ecmascript)\", INNER_DOCUMENT => \"[project]/pages/_document.js [ssr] (ecmascript)\", INNER_APP => \"[project]/pages/_app.js [ssr] (ecmascript)\" } [ssr] (ecmascript)")
module.exports=R.m("[project]/node_modules/next/dist/esm/build/templates/pages.js { INNER_PAGE => \"[project]/pages/index.js [ssr] (ecmascript)\", INNER_DOCUMENT => \"[project]/pages/_document.js [ssr] (ecmascript)\", INNER_APP => \"[project]/pages/_app.js [ssr] (ecmascript)\" } [ssr] (ecmascript)").exports
