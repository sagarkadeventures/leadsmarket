__turbopack_load_page_chunks__("/", [
  "static/chunks/node_modules_next_dist_compiled_next-devtools_index_5277ebc8.js",
  "static/chunks/node_modules_next_dist_compiled_aa9d047d._.js",
  "static/chunks/node_modules_next_dist_shared_lib_16fa510a._.js",
  "static/chunks/node_modules_next_dist_client_bdba867a._.js",
  "static/chunks/node_modules_next_dist_2e2215b7._.js",
  "static/chunks/node_modules_next_image_e7eb52cb.js",
  "static/chunks/node_modules_react-dom_4411d9bd._.js",
  "static/chunks/node_modules_db346ff0._.js",
  "static/chunks/[root-of-the-server]__65fbe05e._.js",
  "static/chunks/[next]_internal_font_google_d84389e8._.css",
  "static/chunks/pages_index_2da965e7._.js",
  "static/chunks/turbopack-pages_index_fcba632e._.js"
])
