self.__BUILD_MANIFEST = {
  "/": [
    "./static/chunks/pages/index.js"
  ],
  "/form": [
    "./static/chunks/pages/form.js"
  ],
  "__rewrites": {
    "afterFiles": [],
    "beforeFiles": [],
    "fallback": []
  },
  "sortedPages": [
    "/",
    "/_app",
    "/_error",
    "/api/hello",
    "/api/klaviyo/sync",
    "/api/lead",
    "/form"
  ]
};self.__BUILD_MANIFEST_CB && self.__BUILD_MANIFEST_CB()