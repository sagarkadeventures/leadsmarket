import LeadForm from '@/components/LeadForm'
import React from 'react'

const Form = () => {
  return (
    <div>
      {/* <h1 className="text-4xl font-bold">Form</h1> */}
      <LeadForm/>
    </div>
  )
}

export default Form
